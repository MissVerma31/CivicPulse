import 'package:flutter/material.dart';
import '../../core/network/dio_client.dart';
import '../../models/reward_model.dart';
import '../../repositories/reward_repo.dart';

class RewardsHistoryScreen extends StatefulWidget {
  const RewardsHistoryScreen({super.key});

  @override
  State<RewardsHistoryScreen> createState() => _RewardsHistoryScreenState();
}

class _RewardsHistoryScreenState extends State<RewardsHistoryScreen> {
  late final RewardRepository _rewardRepository;
  List<RewardHistoryItem> _rewards = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _rewardRepository = RewardRepository(DioClient.createDio());
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final page = await _rewardRepository.getMyRewards(page: 0, size: 50);
      setState(() => _rewards = page.content);
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final totalPoints = _rewards.fold<int>(0, (sum, r) => sum + r.points);

    return Scaffold(
      appBar: AppBar(title: const Text('Rewards History')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? ListView(
          children: [
            const SizedBox(height: 100),
            Center(child: Text(_error!)),
          ],
        )
            : _rewards.isEmpty
            ? ListView(
          children: const [
            SizedBox(height: 150),
            Icon(Icons.stars_outlined, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Center(child: Text('No rewards yet')),
            Center(
              child: Text(
                'Get points when your complaints are verified and resolved',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey),
              ),
            ),
          ],
        )
            : ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              color: Colors.amber.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total Points', style: TextStyle(fontWeight: FontWeight.w600)),
                    Text(
                      '$totalPoints',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.orange,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            ..._rewards.map((r) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: const CircleAvatar(
                  backgroundColor: Colors.amber,
                  child: Icon(Icons.stars, color: Colors.white, size: 20),
                ),
                title: Text(r.readableReason),
                subtitle: Text(
                  r.complaintTitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: Text(
                  '+${r.points}',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                    fontSize: 15,
                  ),
                ),
              ),
            )),
          ],
        ),
      ),
    );
  }
}