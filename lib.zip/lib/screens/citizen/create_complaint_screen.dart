import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/network/dio_client.dart';
import '../../core/services/location_service.dart';
import '../../core/services/image_upload_service.dart';
import '../../models/category_model.dart';
import '../../models/complaint_model.dart';
import '../../repositories/category_repo.dart';
import '../../repositories/complaint_repo.dart';

class CreateComplaintScreen extends StatefulWidget {
  const CreateComplaintScreen({super.key});

  @override
  State<CreateComplaintScreen> createState() => _CreateComplaintScreenState();
}

class _CreateComplaintScreenState extends State<CreateComplaintScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  final _addressController = TextEditingController();
  final _cityController = TextEditingController();
  final _wardController = TextEditingController();

  late final CategoryRepository _categoryRepository;
  late final ComplaintRepository _complaintRepository;

  List<Category> _categories = [];
  Category? _selectedCategory;
  bool _isLoadingCategories = true;
  bool _isSubmitting = false;
  String? _error;

  // Location state
  double? _latitude;
  double? _longitude;
  bool _isDetectingLocation = false;

  // Photo state
  Uint8List? _photoBytes;
  String? _uploadedPhotoUrl;
  bool _isUploadingPhoto = false;

  @override
  void initState() {
    super.initState();
    final dio = DioClient.createDio();
    _categoryRepository = CategoryRepository(dio);
    _complaintRepository = ComplaintRepository(dio);
    _loadCategories();
  }

  Future<void> _loadCategories() async {
    try {
      final categories = await _categoryRepository.getCategories();
      setState(() {
        _categories = categories;
        _isLoadingCategories = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load categories: ${e.toString().replaceFirst('Exception: ', '')}';
        _isLoadingCategories = false;
      });
    }
  }

  Future<void> _detectLocation() async {
    setState(() {
      _isDetectingLocation = true;
      _error = null;
    });
    try {
      final result = await LocationService.getCurrentLocationWithAddress();
      setState(() {
        _latitude = result.latitude;
        _longitude = result.longitude;
        if (result.address != null && result.address!.isNotEmpty) {
          _addressController.text = result.address!;
        }
        if (result.city != null && result.city!.isNotEmpty) {
          _cityController.text = result.city!;
        }
      });
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      setState(() => _isDetectingLocation = false);
    }
  }

  Future<void> _capturePhoto() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 70,
      maxWidth: 1280,
    );
    if (picked == null) return;

    final bytes = await picked.readAsBytes();
    setState(() {
      _photoBytes = bytes;
      _uploadedPhotoUrl = null; // reset, will upload on submit
    });
  }

  Future<String?> _ensurePhotoUploaded() async {
    if (_photoBytes == null) return null;
    if (_uploadedPhotoUrl != null) return _uploadedPhotoUrl;

    setState(() => _isUploadingPhoto = true);
    try {
      final url = await ImageUploadService.uploadImage(_photoBytes!);
      setState(() => _uploadedPhotoUrl = url);
      return url;
    } finally {
      setState(() => _isUploadingPhoto = false);
    }
  }

  Future<bool?> _showDuplicateDialog(ComplaintResponse existing) async {
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Similar Complaint Found'),
        content: Text(
          'A similar complaint already exists nearby:\n\n"${existing.title}"\n\nWould you like to upvote it instead of filing a new one?',
        ),
        actions: [
          TextButton(
            onPressed: () async {
              try {
                await _complaintRepository.upvoteComplaint(existing.id);
                if (context.mounted) Navigator.pop(context, true);
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Upvote failed: ${e.toString().replaceFirst('Exception: ', '')}')),
                  );
                  Navigator.pop(context, null);
                }
              }
            },
            child: const Text('Yes, Upvote'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('No, File New'),
          ),
        ],
      ),
    );
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedCategory == null) {
      setState(() => _error = 'Please select a category');
      return;
    }
    if (_latitude == null || _longitude == null) {
      setState(() => _error = 'Please detect your location first');
      return;
    }

    setState(() {
      _isSubmitting = true;
      _error = null;
    });

    try {
      String? photoUrl;
      if (_photoBytes != null) {
        photoUrl = await _ensurePhotoUploaded();
      }

      await _complaintRepository.createComplaint(
        ComplaintCreateRequest(
          title: _titleController.text.trim(),
          description: _descController.text.trim().isEmpty ? null : _descController.text.trim(),
          categoryId: _selectedCategory!.id,
          photoUrl: photoUrl,
          latitude: _latitude!,
          longitude: _longitude!,
          address: _addressController.text.trim().isEmpty ? null : _addressController.text.trim(),
          city: _cityController.text.trim(),
          ward: _wardController.text.trim(),
        ),
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Complaint filed successfully')),
      );
      Navigator.of(context).pop();
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    _addressController.dispose();
    _cityController.dispose();
    _wardController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('File a Complaint')),
      body: _isLoadingCategories
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (_error != null) ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Text(_error!, style: TextStyle(color: Colors.red.shade700)),
                ),
                const SizedBox(height: 16),
              ],

              TextFormField(
                controller: _titleController,
                maxLength: 150,
                decoration: const InputDecoration(
                  labelText: 'Title',
                  border: OutlineInputBorder(),
                ),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Title is required' : null,
              ),
              const SizedBox(height: 8),

              TextFormField(
                controller: _descController,
                maxLength: 2000,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Description (optional)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 8),

              DropdownButtonFormField<Category>(
                initialValue: _selectedCategory,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  border: OutlineInputBorder(),
                ),
                items: _categories
                    .map((c) => DropdownMenuItem(value: c, child: Text(c.name)))
                    .toList(),
                onChanged: (value) => setState(() => _selectedCategory = value),
                validator: (v) => v == null ? 'Select a category' : null,
              ),
              const SizedBox(height: 20),

              // Photo capture
              const Text('Photo', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              if (_photoBytes != null) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.memory(_photoBytes!, height: 180, fit: BoxFit.cover),
                ),
                const SizedBox(height: 8),
              ],
              OutlinedButton.icon(
                onPressed: _isUploadingPhoto ? null : _capturePhoto,
                icon: _isUploadingPhoto
                    ? const SizedBox(
                    height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.camera_alt_outlined),
                label: Text(_photoBytes == null ? 'Capture Photo' : 'Retake Photo'),
              ),
              const SizedBox(height: 20),

              // Location detection
              const Text('Location', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              if (_latitude != null && _longitude != null) ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.green.shade200),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.location_on, color: Colors.green, size: 18),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          '${_latitude!.toStringAsFixed(5)}, ${_longitude!.toStringAsFixed(5)}',
                          style: const TextStyle(fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],
              OutlinedButton.icon(
                onPressed: _isDetectingLocation ? null : _detectLocation,
                icon: _isDetectingLocation
                    ? const SizedBox(
                    height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.my_location),
                label: Text(_latitude == null ? 'Detect My Location' : 'Re-detect Location'),
              ),
              const SizedBox(height: 20),

              TextFormField(
                controller: _addressController,
                maxLength: 500,
                decoration: const InputDecoration(
                  labelText: 'Address (auto-filled, editable)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 8),

              TextFormField(
                controller: _cityController,
                decoration: const InputDecoration(
                  labelText: 'City (auto-filled, editable)',
                  border: OutlineInputBorder(),
                ),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'City is required' : null,
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _wardController,
                decoration: const InputDecoration(
                  labelText: 'Ward',
                  border: OutlineInputBorder(),
                ),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Ward is required' : null,
              ),
              const SizedBox(height: 24),

              ElevatedButton(
                onPressed: _isSubmitting ? null : _submit,
                style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                child: _isSubmitting
                    ? const SizedBox(
                    height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Submit Complaint', style: TextStyle(fontSize: 16)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}