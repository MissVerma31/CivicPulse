import 'package:flutter/material.dart';
import '../../core/network/dio_client.dart';
import '../../core/storage/token_storage.dart';
import '../../core/theme/app_theme.dart';
import '../../models/complaint_model.dart';
import '../../repositories/complaint_repo.dart';
import '../../widgets/complaint_tracking_rail.dart'; // NEW
import '../../widgets/sla_badge.dart';
import 'dart:async';

class ComplaintDetailsScreen extends StatefulWidget {
  final int complaintId;
  const ComplaintDetailsScreen({super.key, required this.complaintId});

  @override
  State<ComplaintDetailsScreen> createState() => _ComplaintDetailsScreenState();
}

class _ComplaintDetailsScreenState extends State<ComplaintDetailsScreen> {
  late final ComplaintRepository _complaintRepository;
  ComplaintResponse? _complaint;
  String? _role;
  bool _isLoading = true;
  bool _isActionLoading = false;
  bool _isUpvoting = false;
  Timer? _pollTimer;
  String? _error;

  @override
  @override
  void initState() {
    super.initState();
    _complaintRepository = ComplaintRepository(DioClient.createDio());
    _init();
    _pollTimer = Timer.periodic(
      const Duration(seconds: 20),
          (_) => _silentRefresh(),
    );
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  /// Background refresh: no spinner, errors ignored, skipped while a
  /// load or an action is already running.
  Future<void> _silentRefresh() async {
    if (_isLoading || _isActionLoading || _isUpvoting) return;
    try {
      final c = await _complaintRepository.getComplaintById(widget.complaintId);
      if (mounted) setState(() => _complaint = c);
    } catch (_) {}
  }
  Future<void> _init() async {
    _role = await TokenStorage.getRole();
    await _loadComplaint();
  }

  Future<void> _loadComplaint() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final c = await _complaintRepository.getComplaintById(widget.complaintId);
      setState(() => _complaint = c);
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _runAction(Future<void> Function() action) async {
    setState(() => _isActionLoading = true);
    try {
      await action();
      await _loadComplaint();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    } finally {
      if (mounted) setState(() => _isActionLoading = false);
    }
  }

  Future<void> _showPriorityDialog() async {
    String priority = 'MEDIUM';
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Verify Complaint'),
        content: StatefulBuilder(
          builder: (context, setDialogState) => DropdownButtonFormField<String>(
            initialValue: priority,
            decoration: const InputDecoration(labelText: 'Priority'),
            items: const [
              DropdownMenuItem(value: 'LOW', child: Text('Low')),
              DropdownMenuItem(value: 'MEDIUM', child: Text('Medium')),
              DropdownMenuItem(value: 'HIGH', child: Text('High')),
            ],
            onChanged: (v) => setDialogState(() => priority = v ?? 'MEDIUM'),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, priority),
            child: const Text('Verify'),
          ),
        ],
      ),
    );

    if (result != null) {
      _runAction(() => _complaintRepository.verifyComplaint(widget.complaintId, result));
    }
  }

  Future<void> _showResolveDialog() async {
    final noteController = TextEditingController();
    final photoController = TextEditingController();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Resolve Complaint'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: noteController,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Resolution note'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: photoController,
              decoration: const InputDecoration(
                labelText: 'Resolution photo URL (required)',
                hintText: 'https://...',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              if (photoController.text.trim().isEmpty) return;
              Navigator.pop(context, true);
            },
            child: const Text('Resolve'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      _runAction(() => _complaintRepository.resolveComplaint(
        widget.complaintId,
        noteController.text.trim(),
        photoController.text.trim(),
      ));
    }
  }

  Future<void> _showRejectDialog() async {
    final reasonController = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reject Complaint'),
        content: TextField(
          controller: reasonController,
          maxLines: 3,
          decoration: const InputDecoration(labelText: 'Reason for rejection'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              if (reasonController.text.trim().isEmpty) return;
              Navigator.pop(context, true);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Reject'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      _runAction(() => _complaintRepository.rejectComplaint(widget.complaintId, reasonController.text.trim()));
    }
  }

  Future<void> _upvote() async {
    setState(() => _isUpvoting = true);
    try {
      await _complaintRepository.upvoteComplaint(widget.complaintId);
      // Refresh just the complaint (no full-screen spinner) to show the new count.
      final c = await _complaintRepository.getComplaintById(widget.complaintId);
      if (!mounted) return;
      setState(() => _complaint = c);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Upvoted')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    } finally {
      if (mounted) setState(() => _isUpvoting = false);
    }
  }

  Widget _buildUpvoteRow() {
    if (_complaint == null) return const SizedBox.shrink();
    final status = _complaint!.status;
    final isAuthority = (_role ?? '').toUpperCase() == 'AUTHORITY';
    final canUpvote = !isAuthority &&
        status != ComplaintStatus.rejected &&
        status != ComplaintStatus.closed;
    final count = _complaint!.upvoteCount;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          const Icon(Icons.arrow_upward_rounded, size: 20, color: AppColors.primary),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              '$count community upvote${count == 1 ? '' : 's'}',
              style: Theme.of(context)
                  .textTheme
                  .bodyLarge
                  ?.copyWith(fontWeight: FontWeight.w600),
            ),
          ),
          if (canUpvote)
            OutlinedButton(
              onPressed: _isUpvoting ? null : _upvote,
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(0, 38),
                padding: const EdgeInsets.symmetric(horizontal: 16),
              ),
              child: _isUpvoting
                  ? const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
                  : const Text('Upvote'),
            ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    if (_complaint == null || _role == null) return const SizedBox.shrink();
    final status = _complaint!.status;
    final isAuthority = _role!.toUpperCase() == 'AUTHORITY';

    final buttons = <Widget>[];

    if (isAuthority) {
      // FIXED: this pendingVerification block was duplicated in the
      // original file, adding "Verify & Set Priority" twice. Merged into
      // a single if/else-if chain below.
      if (status == ComplaintStatus.pendingVerification) {
        buttons.add(ElevatedButton.icon(
          onPressed: _isActionLoading ? null : _showPriorityDialog,
          icon: const Icon(Icons.verified_outlined),
          label: const Text('Verify & Set Priority'),
        ));
        buttons.add(OutlinedButton.icon(
          onPressed: _isActionLoading ? null : _showRejectDialog,
          icon: const Icon(Icons.cancel_outlined, color: Colors.red),
          label: const Text('Reject', style: TextStyle(color: Colors.red)),
          style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.red)),
        ));
      } else if (status == ComplaintStatus.verified) {
        buttons.add(ElevatedButton.icon(
          onPressed: _isActionLoading
              ? null
              : () => _runAction(() => _complaintRepository.startProgress(widget.complaintId)),
          icon: const Icon(Icons.play_arrow),
          label: const Text('Start Progress'),
        ));
      } else if (status == ComplaintStatus.inProgress) {
        buttons.add(ElevatedButton.icon(
          onPressed: _isActionLoading ? null : _showResolveDialog,
          icon: const Icon(Icons.check_circle_outline),
          label: const Text('Resolve'),
        ));
      }
    } else {
      // citizen actions
      if (status == ComplaintStatus.resolved) {
        buttons.add(ElevatedButton.icon(
          onPressed: _isActionLoading
              ? null
              : () => _runAction(() => _complaintRepository.closeComplaint(widget.complaintId)),
          icon: const Icon(Icons.done_all),
          label: const Text('Close Complaint'),
        ));
      }
    }

    if (buttons.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: buttons
            .map((b) => Padding(padding: const EdgeInsets.only(bottom: 8), child: b))
            .toList(),
      ),
    );
  }

  Widget _infoRow(String label, String? value) {
    if (value == null || value.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(label, style: const TextStyle(color: Colors.grey, fontSize: 13)),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Complaint Details')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
          ? Center(child: Text(_error!))
          : RefreshIndicator(
        onRefresh: _loadComplaint,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text(_complaint!.title,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            // CHANGED: plain Chip replaced with the themed StatusBadge
            // (colored pill matching the status: pending/verified/resolved/etc).
            Wrap(
              spacing: 8,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                StatusBadge(status: _complaint!.status.name),
                SlaBadge(complaint: _complaint!),
              ],
            ),
            const SizedBox(height: 20),

            // NEW: the Civic Tracking Progress Rail -- visual step tracker
            // for the complaint's lifecycle. Sits right below the status
            // badge, above the description, so it's the first thing a
            // citizen or authority sees when opening the details screen.
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: ComplaintTrackingRail(
                status: _complaint!.status,
                rejectionReason: _complaint!.rejectionReason,
                createdAt: _complaint!.createdAt,
                verifiedAt: _complaint!.verifiedAt,
                resolvedAt: _complaint!.resolvedAt,
              ),
            ),
            const SizedBox(height: 20),

            _buildUpvoteRow(),
            const SizedBox(height: 20),

            if (_complaint!.description != null) ...[
              Text(_complaint!.description!),
              const SizedBox(height: 16),
            ],

            const Divider(),
            _infoRow('Category', _complaint!.categoryName),
            _infoRow('Department', _complaint!.department),
            _infoRow('Priority', _complaint!.priority),
            _infoRow('Address', _complaint!.address),
            _infoRow('City', _complaint!.city),
            _infoRow('Ward', _complaint!.ward),
            _infoRow('Citizen', _complaint!.citizenName),
            _infoRow('Assigned Authority', _complaint!.assignedAuthorityName),
            if (_complaint!.rejectionReason != null)
              _infoRow('Rejection Reason', _complaint!.rejectionReason),
            if (_complaint!.resolutionNote != null)
              _infoRow('Resolution Note', _complaint!.resolutionNote),

            const Divider(),
            _infoRow('Created', _complaint!.createdAt?.toLocal().toString()),
            _infoRow('Verified', _complaint!.verifiedAt?.toLocal().toString()),
            _infoRow('Resolved', _complaint!.resolvedAt?.toLocal().toString()),

            if (_isActionLoading) ...[
              const SizedBox(height: 16),
              const Center(child: CircularProgressIndicator()),
            ],

            _buildActionButtons(),
          ],
        ),
      ),
    );
  }
}