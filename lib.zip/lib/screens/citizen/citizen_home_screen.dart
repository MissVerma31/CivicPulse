import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/network/dio_client.dart';
import '../../core/services/notification_store.dart';
import '../../core/storage/token_storage.dart';
import '../../core/theme/app_theme.dart';
import '../../models/auth_models.dart';
import '../../models/complaint_model.dart';
import '../../repositories/auth_repo.dart';
import '../../repositories/complaint_repo.dart';
import '../../repositories/reward_repo.dart';
import '../../widgets/sla_badge.dart';
import '../auth/role_selection_screen.dart';
import 'complaint_details_screen.dart';
import 'notification_screen.dart';
import 'reward_history_screen.dart';
import 'package:flutter/foundation.dart';

class CitizenHomeScreen extends StatefulWidget {
  /// Bump this notifier's value to make the screen reload (used by the
  /// shell after a new complaint is filed from the bottom bar).
  final ValueListenable<int>? refreshTrigger;

  /// Called when the points card is tapped. The shell uses this to switch
  /// to the Rewards tab. If null, the rewards screen is pushed instead.
  final VoidCallback? onOpenRewards;

  const CitizenHomeScreen({super.key, this.refreshTrigger, this.onOpenRewards});

  @override
  State<CitizenHomeScreen> createState() => _CitizenHomeScreenState();
}

class _CitizenHomeScreenState extends State<CitizenHomeScreen> {
  late final ComplaintRepository _complaintRepository;
  late final RewardRepository _rewardRepository;
  List<ComplaintResponse> _complaints = [];
  UserResponse? _currentUser;
  List<String>? _badges;
  bool _isLoading = true;
  String? _error;

  Timer? _pollTimer;
  bool _polling = false;

  @override
  void initState() {
    super.initState();
    _complaintRepository = ComplaintRepository(DioClient.createDio());
    _rewardRepository = RewardRepository(DioClient.createDio());
    widget.refreshTrigger?.addListener(_onRefreshTrigger);
    _loadComplaints();
    _loadProfile();
    _loadBadges();
    // Live tracking: quietly re-check complaints every 25 seconds.
    _pollTimer = Timer.periodic(const Duration(seconds: 25), (_) => _poll());
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    widget.refreshTrigger?.removeListener(_onRefreshTrigger);
    super.dispose();
  }

  void _onRefreshTrigger() {
    _loadComplaints();
    _loadProfile();
    _loadBadges();
  }

  Future<void> _poll() async {
    if (_polling || _isLoading) return;
    _polling = true;
    try {
      await _loadComplaints(silent: true);
    } finally {
      _polling = false;
    }
  }

  Future<void> _loadProfile() async {
    try {
      final authRepo = AuthRepository(DioClient.createDio());
      final user = await authRepo.getCurrentUser();
      if (mounted) setState(() => _currentUser = user);
    } catch (_) {
      // non-critical — points card just won't show if this fails
    }
  }

  Future<void> _loadBadges() async {
    try {
      final badges = await _rewardRepository.getMyBadges();
      if (mounted) setState(() => _badges = badges);
    } catch (_) {
      // non-critical — badges section just won't show if this fails
    }
  }

  /// [silent] = background refresh: no spinner, and errors are ignored so
  /// the list on screen is never wiped by a failed poll.
  Future<void> _loadComplaints({bool silent = false}) async {
    if (!silent) {
      setState(() {
        _isLoading = true;
        _error = null;
      });
    }
    try {
      final page = await _complaintRepository.getMyComplaints(page: 0, size: 20);
      if (!mounted) return;
      final changed = NotificationStore.instance.checkComplaints(page.content);
      setState(() => _complaints = page.content);
      if (changed) {
        // A status change can also mean new points or a new badge.
        _loadProfile();
        _loadBadges();
      }
    } catch (e) {
      if (!mounted) return;
      if (!silent) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    } finally {
      if (mounted && !silent) setState(() => _isLoading = false);
    }
  }

  Future<void> _refreshAll() async {
    _loadProfile();
    _loadBadges();
    await _loadComplaints();
  }

  Future<void> _logout() async {
    await TokenStorage.clearToken();
    NotificationStore.instance.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const RoleSelectionScreen()),
          (route) => false,
    );
  }

  void _openNotifications() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const NotificationsScreen()),
    );
  }

  void _openRewards() {
    if (widget.onOpenRewards != null) {
      widget.onOpenRewards!();
    } else {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const RewardsHistoryScreen()),
      );
    }
  }

  String _formatDate(DateTime? d) {
    if (d == null) return '';
    final l = d.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(l.day)}/${two(l.month)}/${l.year}';
  }

  Widget _buildPointsCard() {
    final textTheme = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: _openRewards,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppColors.tertiary.withValues(alpha: 0.15),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.stars_rounded, color: AppColors.tertiary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Reputation points', style: textTheme.bodySmall),
                      Text('${_currentUser!.reputationPoints}', style: textTheme.titleLarge),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right, color: AppColors.textMuted),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBadgesCard() {
    final textTheme = Theme.of(context).textTheme;
    final badges = _badges ?? const <String>[];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Your badges', style: textTheme.bodySmall),
            const SizedBox(height: 8),
            if (badges.isEmpty)
              Text(
                'Earn your first badge by reporting an issue',
                style: textTheme.bodyMedium?.copyWith(color: AppColors.textMuted),
              )
            else
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: badges.map(_buildBadgeChip).toList(),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildBadgeChip(String name) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.tertiary.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.tertiary.withValues(alpha: 0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.military_tech_rounded, size: 16, color: AppColors.tertiary),
          const SizedBox(width: 6),
          Text(
            name,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  Widget _buildComplaintCard(ComplaintResponse c) {
    final textTheme = Theme.of(context).textTheme;
    final subtitle = [c.categoryName, c.city]
        .where((s) => s != null && s.isNotEmpty)
        .join(' • ');

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () async {
          await Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => ComplaintDetailsScreen(complaintId: c.id)),
          );
          _loadComplaints(silent: true);
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      c.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ),
                  const SizedBox(width: 8),
                  StatusBadge(status: c.status.name),
                ],
              ),
              if (subtitle.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(subtitle, style: textTheme.bodyMedium),
              ],
              const SizedBox(height: 10),
              Row(
                children: [
                  const Icon(Icons.arrow_upward_rounded, size: 14, color: AppColors.textMuted),
                  const SizedBox(width: 4),
                  Text('${c.upvoteCount}', style: textTheme.bodySmall),
                  const SizedBox(width: 10),
                  SlaBadge(complaint: c),
                  const Spacer(),
                  Text(_formatDate(c.createdAt), style: textTheme.bodySmall),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Complaints'),
        actions: [
          IconButton(
            tooltip: 'Notifications',
            onPressed: _openNotifications,
            icon: ListenableBuilder(
              listenable: NotificationStore.instance,
              builder: (context, _) {
                final n = NotificationStore.instance.unreadCount;
                return Badge(
                  isLabelVisible: n > 0,
                  label: Text('$n'),
                  child: const Icon(Icons.notifications_outlined),
                );
              },
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: _logout,
          ),
        ],
      ),
      body: Column(
        children: [
          if (_currentUser != null) _buildPointsCard(),
          if (_badges != null) _buildBadgesCard(),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _refreshAll,
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : _error != null
                  ? ListView(
                children: [
                  const SizedBox(height: 100),
                  Center(child: Text(_error!)),
                  const SizedBox(height: 16),
                  Center(
                    child: SizedBox(
                      width: 140,
                      child: ElevatedButton(
                        onPressed: _loadComplaints,
                        child: const Text('Retry'),
                      ),
                    ),
                  ),
                ],
              )
                  : _complaints.isEmpty
                  ? ListView(
                children: const [
                  SizedBox(height: 150),
                  Icon(Icons.inbox_outlined, size: 64, color: AppColors.textMuted),
                  SizedBox(height: 16),
                  Center(child: Text('No complaints yet')),
                  SizedBox(height: 4),
                  Center(
                    child: Text(
                      'Tap Report below to file your first complaint',
                      style: TextStyle(color: AppColors.textMuted),
                    ),
                  ),
                ],
              )
                  : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _complaints.length,
                itemBuilder: (context, index) =>
                    _buildComplaintCard(_complaints[index]),
              ),
            ),
          ),
        ],
      ),
    );
  }
}