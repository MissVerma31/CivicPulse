import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

class ImageUploadService {
  static const String _imgbbApiKey = '340860bef1c0507cec7475c4fca4e74a';

  /// Uploads image bytes to imgbb and returns the public image URL.
  static Future<String> uploadImage(Uint8List imageBytes) async {
    final base64Image = base64Encode(imageBytes);

    final response = await http.post(
      Uri.parse('https://api.imgbb.com/1/upload?key=$_imgbbApiKey'),
      body: {'image': base64Image},
    );

    if (response.statusCode != 200) {
      throw Exception('Image upload failed (${response.statusCode})');
    }

    final data = jsonDecode(response.body);
    final url = data['data']?['url'];
    if (url == null) {
      throw Exception('Image upload succeeded but no URL returned');
    }
    return url as String;
  }
}